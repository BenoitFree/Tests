def saut_de_ligne(contenu, longueur):
    if not isinstance(contenu, str) or not isinstance(longueur, int):
        raise TypeError("{0} ou {1} est incorrecte".format(contenu, longueur))

    value = ""
    return value

def saut_de_ligne_v2(contenu, longueur):
    if not isinstance(contenu, str) or not isinstance(longueur, int):
        raise TypeError("{0} ou {1} est incorrecte".format(contenu, longueur))

    value = ""
    return value

#Je n'ai pas réussi cet exercice
