# QCM
**1 : Dans un langage orienté objet la unité de test peut tester :**
- a. une fonction
- d. Une classe

**2 : Quel(s) phrase(s) décrivent la méthodologie TDD**
- a. Ecrire les tests, développer la fonctionnalité jusqu’à ce que tous mes tests passent
- b. Je répète le processus : écriture d’un test, développement, refacto

**3 : Les tests unitaires peuvent me permettre de vérifier :**
- a. Les erreurs levées d’une fonctions
- c. Les valeurs retours
- e. Les valeurs limites

**4 : Lorsque j’écris un tests je détermine les paramètres en utilisant :**
- a. Des valeurs limites
- b. Des valeurs incorrectes

**5 : Le concept de Mock me permet lors de l’écriture des tests :**
- b. De simuler le fonctionnement d’une dépendance
