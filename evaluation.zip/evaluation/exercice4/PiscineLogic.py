class PiscineLogic:
    def get_actual_temp(self):
        pass

    def get_last_days_temps(self):
        pass

    def set_heater(self, heater_value):
        pass